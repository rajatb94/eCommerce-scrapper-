/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.mycompany.hdp;

/**
*
* @author rajat
*/
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class hdp {
    private static Date dt = new Date();
    private static int success=0;
    private static String date;
    private static void saveFile(String date) throws FileNotFoundException, IOException, URISyntaxException
    {
        
        
        Configuration configuration = new Configuration();
        configuration.set("fs.hdfs.impl",
        org.apache.hadoop.hdfs.DistributedFileSystem.class.getName()
        );
        configuration.set("fs.file.impl",
        org.apache.hadoop.fs.LocalFileSystem.class.getName()
        );
        FileSystem hdfs = FileSystem.get(new URI("hdfs://104.236.110.203:9000"), configuration);
        hdfs.copyFromLocalFile(new Path(new URI("data/" + date + "/")), new Path(new URI("hdfs://104.236.110.203:9000/cdata/")));
        
    }
    
    private static void crawl(String query)
    {
        
        
        
        getDetails gd=new getDetails();
        try
        {
            //gd.get_costco(query,date);
            success++;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            // gd.get_bestbuy(query,date);
            success++;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            //gd.get_homedepote(query,date);
            success++;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            //gd.get_walmart(query,date);
            success++;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            gd.get_amazon(query,date);
            success++;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
       
    }
    
    public static void main(String[] args) throws IOException, FileNotFoundException, URISyntaxException
    {
        date=dt.toString().replaceAll(" ", "_").replaceAll(":","-");
       crawl("iphone");
       crawl("ipad");
       crawl("samsung mobile phones");
       crawl("samsung tablet");
         if(success>0)
        {
            try
            {
                saveFile(date);
                FileUtils.deleteDirectory(new File("data"));
                System.out.println("DONE");
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
            
        }
        
        else
        {
            System.out.println("Something Went Wrong Try to Fix the Error:::::");
            
        }
        
    }
}
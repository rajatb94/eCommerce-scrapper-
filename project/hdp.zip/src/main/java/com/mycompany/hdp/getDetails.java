/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.mycompany.hdp;

/**
*
* @author rajat
*/
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

/**
*
* @author rajat
*/
public class getDetails {
    
    private static String qr;
    
    //############################################################################ COSCOTO
    public void get_costco(String query, String date) throws IOException
    {
        qr =query.replaceAll(" ","_");
        Document doc = Jsoup.connect("http://www.costco.com/CatalogSearch?storeId=10301&catalogId=10701&langId=-1&refine=&keyword=" + query).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        Elements d = doc.getElementsByAttributeValue("class", "pagination").get(0).getElementsByTag("li");
        int s=Integer.parseInt(d.get(d.size()-1).text());
        for(int i=1;i<=s;i++)
        {
            
            get_all_costco("http://www.costco.com/CatalogSearch?pageSize=96&catalogId=10701&currentPage=" + i + "&langId=-1&keyword=" + query + "&storeId=10301", date);
            
        }
    }
    public static void get_all_costco(String url,  String date) throws IOException
    {
        
        Document doc = Jsoup.connect(url).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        Elements d = doc.getElementsByAttributeValue("class", "product-tile comparable");
        
        for(int i=0;i<d.size();i++)
        {
            int nameS=d.get(i).getElementsByAttributeValue("class","short-desc").size();
            int priceS=d.get(i).getElementsByAttributeValue("class","currency ").size();
            
            if(nameS==1 && priceS==1)
            {
                String name=d.get(i).getElementsByAttributeValue("class","short-desc").get(0).text();
                String price=d.get(i).getElementsByAttributeValue("class","currency").get(0).text();
                int ratingC=d.get(i).getElementsByAttributeValue("class","product-rating").size();
                String rating;
                if(ratingC>0)
                {
                    rating=d.get(i).getElementsByAttributeValue("class","product-rating").get(0).text();
                }
                else
                {
                    rating="Not Rated";
                }
                try
                {
                    File file = new File("data/" + date + "/" + qr +  "/costco_" + qr + "__" + date + ".csv");
                    file.setExecutable(true);
                    file.setReadable(true);
                    file.setWritable(true);
                    file.getParentFile().mkdirs();
                    FileWriter fw = new FileWriter(file,true); //the true will append the new data
                    fw.write("\"" + name + "\",\"" + price + "\",\"" + rating + "\"\n");//appends the string to the file  product-rating
                    fw.close();
                }
                catch(IOException ioe)
                {
                    System.err.println("IOException: " + ioe.getMessage());
                }
            }
        }
    }
    //############################################################################ END - COSCOTO
    
    
    //############################################################################ BESTBUY
    public void get_bestbuy(String query,  String date) throws IOException
    {
        qr =query.replaceAll(" ","_");
        Document doc = Jsoup.connect("http://www.bestbuy.com/site/searchpage.jsp?_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=25&sp=&qp=&list=n&iht=y&usc=All+Categories&ks=960&fs=saas&saas=saas&keys=keys&st=" + query).timeout(10*1000).get();
        Elements d = doc.getElementsByAttributeValue("class", "pagination-section").get(0).getElementsByTag("li");
        int s=Integer.parseInt(d.get(d.size()-2).text());
        for(int i=1;i<=s;i++)
        {
            
            get_all_bestbuy("http://www.bestbuy.com/site/searchpage.jsp?_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=" + i + "&nrp=25&sp=&qp=&list=n&iht=y&usc=All%20Categories&ks=960&fs=saas&saas=saas&keys=keys&st=" + query, date);
            
        }
    }
    public static void get_all_bestbuy(String url,  String date) throws IOException
    {
        
        Document doc = Jsoup.connect(url).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        Elements d = doc.getElementsByAttributeValue("class", "list-item");
        //System.out.println(d.size());
        for(int i=0;i<d.size();i++)
        {
            int nameS=d.get(i).getElementsByAttributeValue("class","sku-title").size();
            int priceS=d.get(i).getElementsByAttributeValue("class","medium-item-price").size();
            int modelS=d.get(i).getElementsByAttributeValue("itemprop","model").size();
            int specsS=d.get(i).getElementsByAttributeValue("class","short-description").size();
            int offersS=d.get(i).getElementsByAttributeValue("class","special-offers").size();
            int ratingS=d.get(i).getElementsByAttributeValue("class","average-score").size();
            //System.out.println(nameS + "  " + priceS + "  " + modelS + "  " + specsS + " " + offersS + " " + ratingS);
            if(nameS > 0 && priceS > 0 && ratingS > 0 && specsS > 0 && offersS >0 && ratingS>0)
            {
                
                //System.out.println(nameS + "  " + priceS + "  " + companyS + "  " + ratingS); model-value
                String name=d.get(i).getElementsByAttributeValue("class","sku-title").get(0).text();
                String price=d.get(i).getElementsByAttributeValue("class","medium-item-price").get(0).text();
                String model;
                if(modelS==0)
                model="";
                else
                    model=d.get(i).getElementsByAttributeValue("itemprop","model").get(0).text();
                String specs=d.get(i).getElementsByAttributeValue("class","short-description").get(0).text();
                String offers=d.get(i).getElementsByAttributeValue("class","special-offers").get(0).text();
                String rating=d.get(i).getElementsByAttributeValue("class","average-score").text();
                
                
                
                
                try
                {
                    File file = new File("data/" + date + "/" + qr + "/bestbuy_" + qr + "__" + date + ".csv");
                    file.setExecutable(true);
                    file.setReadable(true);
                    file.setWritable(true);
                    file.getParentFile().mkdirs();
                    FileWriter fw = new FileWriter(file,true); //the true will append the new data
                    fw.write("\"" + name + "\",\"" + price + "\",\"" + model + "\",\"" + specs + "\",\"" + offers + "\",\"" + rating + "\"\n");//appends the string to the file
                    fw.close();
                }
                catch(IOException ioe)
                {
                    System.err.println("IOException: " + ioe.getMessage());
                }
            }
            
            /*
            */
        }
    }
    //############################################################################ END - BESTBUY
    
    //############################################################################ HOMEDEPOTE
    public void get_homedepote(String query,  String date) throws IOException
    {
        
        qr =query.replaceAll(" ","_");
        
        Document doc = Jsoup.connect("http://www.homedepot.com/s/" + query).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        Elements d = doc.getElementsByAttributeValue("class", "pagination-wrapper").get(0).getElementsByTag("li");
        int s=Integer.parseInt(d.get(d.size()-2).text().trim());
        //System.out.println(s);
        for(int i=1;i<=s;i++)
        {
            if(i==1)
            {
                get_all_homedepote("http://www.homedepot.com/s/" + query, date);
            }
            else
            {
                get_all_homedepote("http://www.homedepot.com/b/N-5yc1v/Ntk-SemanticSearch/Ntt-" + query + "?Nao=" + (i-1)*24 + "&Ntx=mode%20matchall",  date);
            }
            
        }
    }
    
    
    public static void get_all_homedepote(String url,  String date) throws IOException
    {
        
        Document doc = Jsoup.connect(url).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        
        Elements d = doc.getElementsByClass("product");
        //System.out.println(d.size());
        // System.out.println(doc.html());
        
        for(int i=0;i<d.size();i++)
        {
            int nameS=d.get(i).getElementsByAttributeValue("class","item_description position_tracking_btn").size();
            int priceS=d.get(i).getElementsByAttributeValue("class","xlarge item_price").size();
            int modelS=d.get(i).getElementsByAttributeValue("class","model_container").size();
            int shippingS=d.get(i).getElementsByAttributeValue("class", "shippingItems").size();
            int ratingsS=d.get(i).getElementsByAttributeValue("class", "ratings").size();
            //System.out.println(nameS + "  " + priceS + "  " + modelS);
            if(nameS>0 && priceS>0 && modelS>0 && shippingS>0 && ratingsS>0)
            {
                String name=d.get(i).getElementsByAttributeValue("class","item_description position_tracking_btn").get(0).text();
                String price=d.get(i).getElementsByAttributeValue("class","xlarge item_price").get(0).text();
                String model=d.get(i).getElementsByAttributeValue("class","model_container").get(0).getElementsByTag("span").get(1).text();
                String shd1=d.get(i).getElementsByAttributeValue("class","shippingItems").get(0).getElementsByTag("li").get(0).text();
                String shd2=d.get(i).getElementsByAttributeValue("class","shippingItems").get(0).getElementsByTag("li").get(1).text();
                String ratings=d.get(i).getElementsByAttributeValue("class","ratings").get(0).getElementsByTag("span").get(0).attr("rel");
                
                try
                {
                    File file = new File("data/" + date + "/" + qr +  "/homedepote_" + qr + "__" + date + ".csv");
                    file.setExecutable(true);
                    file.setReadable(true);
                    file.setWritable(true);
                    file.getParentFile().mkdirs();
                    FileWriter fw = new FileWriter(file,true); //the true will append the new data
                    fw.write("\"" + name + "\",\"" + price + "\",\"" + model + "\",\"" + shd1 + "\",\"" + shd2 + "\",\"" + ratings + "\"\n");//appends the string to the file  product-rating
                    fw.close();
                }
                catch(IOException ioe)
                {
                    System.err.println("IOException: " + ioe.getMessage());
                }
            }
        }
    }
    //############################################################################ END - HOMEDEPOTE
    
    //############################################################################ WALMART
    public void get_walmart(String query,  String date) throws IOException
    {
        qr =query.replaceAll(" ","_");
        Document doc = Jsoup.connect("http://www.walmart.com/search/?query=" + query).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        Elements d = doc.getElementsByAttributeValue("class", "paginator-list").get(0).getElementsByTag("li");
        int s=Integer.parseInt(d.get(d.size()-1).text().trim());
        for(int i=1;i<=s;i++)
        {
            get_all_walmart("http://www.walmart.com/search/?query=" + query + "&page=" + i + "&cat_id=0", date);
            
            
        }
    }
    
    
    public static void get_all_walmart(String url,  String date) throws IOException
    {
        
        Document doc = Jsoup.connect(url).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        
        Elements d = doc.getElementsByClass("tile-content");
        // System.out.println(doc.html());
        
        for(int i=0;i<d.size();i++)
        {
            int nameS=d.get(i).getElementsByAttributeValue("class","tile-heading").size();
            int priceS=d.get(i).getElementsByAttributeValue("class","price price-display").size();
            int specsS=d.get(i).getElementsByAttributeValue("class","quick-specs module").size();
            int vendorS=d.get(i).getElementsByAttributeValue("class", "tile-aside-content").size();
            //System.out.println(nameS + "  " + priceS + "  " + modelS);
            if(nameS>0 && priceS>0 && specsS>0 && vendorS>0)
            {
                String name=d.get(i).getElementsByAttributeValue("class","tile-heading").get(0).text();
                String price=d.get(i).getElementsByAttributeValue("class","price price-display").get(0).text();
                String specs=d.get(i).getElementsByAttributeValue("class","quick-specs module").get(0).text();
                String vendor=d.get(i).getElementsByAttributeValue("class","tile-aside-content").get(0).text();
                float star=d.get(i).getElementsByAttributeValue("class","star star-rated").size();
                int partial=d.get(i).getElementsByAttributeValue("class","star star-partial").size();
                if(partial==1)
                {
                    star+=0.5;
                }
                //String ratings=d.get(i).getElementsByAttributeValue("class","ratings").get(0).getElementsByTag("span").get(0).attr("rel");
                
                try
                {
                    File file = new File("data/" + date + "/" + qr +  "/walmart_" + qr + "__" + date + ".csv");
                    file.setExecutable(true);
                    file.setReadable(true);
                    file.setWritable(true);
                    file.getParentFile().mkdirs();
                    FileWriter fw = new FileWriter(file,true); //the true will append the new data
                    fw.write("\"" + name + "\",\"" + price + "\",\"" + specs + "\",\"" + vendor + "\",\"" + star + "\"\n");//appends the string to the file  product-rating
                    fw.close();
                }
                catch(IOException ioe)
                {
                    System.err.println("IOException: " + ioe.getMessage());
                }
            }
        }
        
    }
    //############################################################################ END - WALMART
    
    //############################################################################ AMAZON
    public void get_amazon(String query,  String date) throws IOException
    {
        
        qr =query.replaceAll(" ","_");
        
        Document doc = Jsoup.connect("http://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=" + query).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        Elements d = doc.getElementsByClass("pagnDisabled");
        int s=Integer.parseInt(d.get(0).text().trim());
        for(int i=1;i<=s;i++)
        {
            get_all_amazon("http://www.amazon.com/s/ref=sr_pg_2?rh=i%3Aaps%2Ck%3A" + query + "&page=" + i + "&keywords=" + query + "&ie=UTF8&qid=1435133659&spIA=B00VTRO3GU,B00T8HWETG", date);
            
            
        }
    }
    
    
    public static void get_all_amazon(String url,  String date) throws IOException
    {
        
        Document doc = Jsoup.connect(url).userAgent("Mozilla/4.0 (compatible; MSIE 8.0; windows NT 6.0)").timeout(10*1000).followRedirects(true).get();
        
        Elements d = doc.getElementsByClass("s-item-container");
        for(int i=0;i<d.size();i++)
        {
            int nameS=d.get(i).getElementsByAttributeValue("class","a-size-medium a-color-null s-inline s-access-title a-text-normal").size();
            int priceS=d.get(i).getElementsByAttributeValue("class","a-size-base a-color-price s-price a-text-bold").size();
            int dltS=d.get(i).getElementsByAttributeValue("class","a-column a-span5 a-span-last").get(0).getElementsByAttributeValue("class", "a-size-small a-color-secondary").size();
            int vendorS=d.get(i).getElementsByAttributeValue("class","a-row a-spacing-small").get(0).getElementsByAttributeValue("class","a-size-small a-color-secondary").size();
            int ratingS=d.get(i).getElementsByAttributeValue("class","a-popover-trigger a-declarative").size();
            
            if(nameS>0 && priceS>0 && dltS>1 && vendorS>1 && ratingS > 0)
            {
                String name=d.get(i).getElementsByAttributeValue("class","a-size-medium a-color-null s-inline s-access-title a-text-normal").get(0).text();
                String price=d.get(i).getElementsByAttributeValue("class","a-size-base a-color-price s-price a-text-bold").get(0).text();
                String shipping=d.get(i).getElementsByAttributeValue("class","a-column a-span5 a-span-last").get(0).getElementsByAttributeValue("class", "a-size-small a-color-secondary").get(0).text();
                String dtl=d.get(i).getElementsByAttributeValue("class","a-column a-span5 a-span-last").get(0).getElementsByAttributeValue("class", "a-size-small a-color-secondary").get(1).text();
                String vendor=d.get(i).getElementsByAttributeValue("class","a-row a-spacing-small").get(0).getElementsByAttributeValue("class","a-size-small a-color-secondary").get(vendorS-1).text();
                String rating=d.get(i).getElementsByAttributeValue("class","a-popover-trigger a-declarative").get(0).text();
                //String ratings=d.get(i).getElementsByAttributeValue("class","ratings").get(0).getElementsByTag("span").get(0).attr("rel");
                
                try
                {
                    File file = new File("data/" + date + "/" + qr +  "/amazon_" + qr + "__" + date + ".csv");
                    file.setExecutable(true);
                    file.setReadable(true);
                    file.setWritable(true);
                    file.getParentFile().mkdirs();
                    FileWriter fw = new FileWriter(file,true); //the true will append the new data
                    fw.write("\"" + name + "\",\"" + price + "\",\"" + shipping + "\",\"" + dtl + "\",\"" + vendor + "\",\"" + rating + "\"\n");//appends the string to the file  product-rating
                    fw.close();
                }
                catch(IOException ioe)
                {
                    System.err.println("IOException: " + ioe.getMessage());
                }
            }
        }
        
    }
    //############################################################################ END - Amazon
    
}
